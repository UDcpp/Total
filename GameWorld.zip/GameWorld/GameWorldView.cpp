﻿// GameWorldView.cpp

#include "pch.h"
#include "framework.h"
#ifndef SHARED_HANDLERS
#include "GameWorld.h"
#include <windows.h>  // CreateProcess 사용할 때 필요

#endif

#include "GameWorldDoc.h"
#include "GameWorldView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CGameWorldView, CView)

BEGIN_MESSAGE_MAP(CGameWorldView, CView)
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CGameWorldView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(2001, &CGameWorldView::OnAppleGameClicked)
	ON_BN_CLICKED(2002, &CGameWorldView::OnTetrisGameClicked)

END_MESSAGE_MAP()

CGameWorldView::CGameWorldView() noexcept {}
CGameWorldView::~CGameWorldView() {}

BOOL CGameWorldView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

void CGameWorldView::OnDraw(CDC* pDC)
{
	CGameWorldDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// 배경 텍스트 출력 (선택사항)
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(RGB(218, 112, 214));

	// ✔ 폰트 적용
	CFont titleFont;
	titleFont.CreatePointFont(400, _T("배달의민족 도현"));  // 크기 조절 가능
	CFont* pOldFont = pDC->SelectObject(&titleFont);

	// ✔ 화면 중앙 상단보다 약간 아래 위치
	CRect rect;
	GetClientRect(&rect);
	CRect titleRect = rect;
	titleRect.top += 100;  // 👈 원하는 만큼 내려주는 값

	pDC->DrawText(_T("🎮 게임 월드 🎮"), &titleRect, DT_CENTER | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject(pOldFont);
}

void CGameWorldView::CreateButtons()
{
	CRect clientRect;
	GetClientRect(&clientRect);

	int btnWidth = 200;
	int btnHeight = 40;
	int centerX = clientRect.Width() / 2;
	int centerY = clientRect.Height() / 2 + 70; // 👉 버튼도 조금 아래로

	// ✔ 버튼 폰트
	static CFont btnFont;
	if (btnFont.m_hObject == NULL)
		btnFont.CreatePointFont(130, _T("배달의민족 도현"));

	// ▶ 사과 게임 버튼
	appleGameBtn.Create(_T("🍎 사과 게임 🍎"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(centerX - btnWidth - 20, centerY, centerX - 20, centerY + btnHeight), this, 2001);
	appleGameBtn.SetFont(&btnFont);

	// ▶ 테트리스 버튼
	tetrisGameBtn.Create(_T("🧱 테트리스 🧱"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(centerX + 20, centerY, centerX + btnWidth + 20, centerY + btnHeight), this, 2002);
	tetrisGameBtn.SetFont(&btnFont);
}


void CGameWorldView::OnInitialUpdate()
{
	CView::OnInitialUpdate();
	CreateButtons();
}

void CGameWorldView::OnAppleGameClicked()
{
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;

	// 실행 파일명 - 현재 실행 파일과 같은 폴더에 있다고 가정
	CString exePath = _T("AppleGame.exe");

	// TCHAR 버퍼로 변환
	TCHAR cmdLine[MAX_PATH];
	_tcscpy_s(cmdLine, exePath);

	BOOL success = CreateProcess(
		NULL,         // 앱 이름 (NULL이면 커맨드 라인에서 추출)
		cmdLine,      // 커맨드 라인
		NULL, NULL,   // 프로세스/스레드 보안
		FALSE,        // 핸들 상속 X
		0,            // 생성 플래그
		NULL, NULL,   // 환경/작업 디렉토리
		&si, &pi      // 구조체 포인터
	);

	if (success)
	{
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
	else
	{
		AfxMessageBox(_T("사과 게임 실행 실패!"));
	}
}


void CGameWorldView::OnTetrisGameClicked()
{
	STARTUPINFO si = { sizeof(si) };
	PROCESS_INFORMATION pi;

	CString exePath = _T("TetrisMFC.exe");

	TCHAR cmdLine[MAX_PATH];
	_tcscpy_s(cmdLine, exePath);

	BOOL success = CreateProcess(
		NULL, cmdLine,
		NULL, NULL,
		FALSE, 0, NULL, NULL,
		&si, &pi
	);

	if (success)
	{
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
	else
	{
		AfxMessageBox(_T("테트리스 실행 실패!"));
	}
}


void CGameWorldView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CGameWorldView::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}

void CGameWorldView::OnBeginPrinting(CDC*, CPrintInfo*) {}
void CGameWorldView::OnEndPrinting(CDC*, CPrintInfo*) {}

void CGameWorldView::OnRButtonUp(UINT, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CGameWorldView::OnContextMenu(CWnd*, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}

#ifdef _DEBUG
void CGameWorldView::AssertValid() const { CView::AssertValid(); }
void CGameWorldView::Dump(CDumpContext& dc) const { CView::Dump(dc); }
CGameWorldDoc* CGameWorldView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGameWorldDoc)));
	return (CGameWorldDoc*)m_pDocument;
}
#endif