﻿#pragma once
#include <afxwin.h>  // CButton 등 MFC 기본 UI 클래스 선언


class CGameWorldView : public CView
{
protected:
    CGameWorldView() noexcept;
    DECLARE_DYNCREATE(CGameWorldView)

public:
    CGameWorldDoc* GetDocument() const;

protected:
   

public:
    virtual void OnDraw(CDC* pDC);
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual void OnInitialUpdate();

    void CreateButtons(); // 버튼 만드는 함수 선언


protected:
    virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
    virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
    virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

public:
    virtual ~CGameWorldView();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    CButton appleGameBtn;
    CButton tetrisGameBtn;
    CFont btnFont;
    

    afx_msg void OnFilePrintPreview();
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

    afx_msg void OnAppleGameClicked();
    afx_msg void OnTetrisGameClicked();

    DECLARE_MESSAGE_MAP()
};
